package com.si.scheduler;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.*;

import java.util.Calendar;


//we will change the (child)layout background color when the day of week is same.

public class MainActivity extends AppCompatActivity {

    LinearLayout mon, tue, wed, thu, fri; // these LinearLayouts the schdule of day of week
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        Calendar c = Calendar.getInstance(); // It can make program use schedule of day  (이게 시간을 사용할 수 있게 해줍니다.)
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //link  xml with java
        mon = (LinearLayout)findViewById(R.id.mon);
        tue = (LinearLayout)findViewById(R.id.tue);
        wed = (LinearLayout)findViewById(R.id.wed);
        thu = (LinearLayout)findViewById(R.id.thu);
        fri = (LinearLayout)findViewById(R.id.fri);


        //declare.

        // 1 = sunday, 2 = monday, 3 = tuesday .... 7 = saturday.
        // but we don't need sunday and saturday.
        int i = c.get(Calendar.DAY_OF_WEEK);

        // for example, if today is tuesday than i is 3. than change layout background color using setBackgroundColor.
        if(i == 2) {
            mon.setBackgroundColor(Color.rgb(178, 204, 255)); // this color is like sky blue or violet. sorry I can't distinguish exactly color.
        }
        if(i == 3) {
            tue.setBackgroundColor(Color.rgb(178, 204, 255));
        }
        if(i == 4) {
            wed.setBackgroundColor(Color.rgb(178, 204, 255));
        }
        if(i == 5) {
            thu.setBackgroundColor(Color.rgb(178, 204, 255));
        }
        if(i == 6) {
            fri.setBackgroundColor(Color.rgb(178, 204, 255));
        }
    }

}
