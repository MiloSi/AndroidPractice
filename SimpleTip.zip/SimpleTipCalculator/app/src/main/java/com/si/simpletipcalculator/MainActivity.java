package com.si.simpletipcalculator;

//import android.content.Context;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

/*
this program is just show tip when input number.

*/
public class MainActivity extends AppCompatActivity {

    int radioID; // just Remember the state when destroy.

    EditText editT; // the input text that you pay money (일단 얼마 내야 하는지.)
    EditText option; // if you choose option radiobutton than show text and can input number
    TextView tipv; // tip value
    TextView resultv; // total value

    RadioGroup Rgroup; // radiobutto group
    RadioButton b1, b2, b3; // radio button b1 is 15, b2 is 20, b3 is option
    Button bt; // input completely than show tip and total

    double tipP, tip, cost; // tipP can change inputting number to just tip (tip을 확인할 수 있게, 0.15, 0.20 etc)
    String string, Otip;  //  text get from option edittext

    boolean isOption = false; // if b3 option is selected

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //show us this is oncreate state
        Toast.makeText(getApplicationContext(), "onCreate", Toast.LENGTH_SHORT).show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // link java and xml (자바랑 xml이랑 연동시켜서 사용.
        editT = (EditText) findViewById(R.id.Input);
        option = (EditText) findViewById(R.id.option);
        Rgroup = (RadioGroup) findViewById(R.id.Rgroup);

        b1 = (RadioButton) findViewById(R.id.b1);
        b2 = (RadioButton) findViewById(R.id.b2);
        b3 = (RadioButton) findViewById(R.id.b3);

        bt = (Button) findViewById(R.id.bt);

        resultv = (TextView) findViewById(R.id.resultv);
        tipv = (TextView) findViewById(R.id.tipv);


        //when destory, your important value saved, and reuse it.
        if(( savedInstanceState != null )) {

            //when  is saveinstanceState, reload all saved (이 상태이면 저장했던 내용 다 불러옴)
            Toast.makeText(getApplicationContext(), "Show Saving File", Toast.LENGTH_SHORT).show();
            editT.setText(savedInstanceState.getString("Result"));
            tipv.setText(savedInstanceState.getString("tip"));
            resultv.setText(savedInstanceState.getString("total"));
            option.setText(savedInstanceState.getString("option"));
            radioID = savedInstanceState.getInt("radio");
        }

        //when radio button changed. than you choose all value.
        Rgroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                radioID = group.getCheckedRadioButtonId(); // save radiobutton. for destory and restart. (파괴되면 다시 사용하게 저장함)

                if (b1.isChecked()) { //15%
                    tipP = 0.15;
                    isOption = false;
                    option.setVisibility(View.INVISIBLE); // make option text invisible
                } else if (b2.isChecked()) {
                    tipP = 0.20;
                    isOption = false;
                    option.setVisibility(View.INVISIBLE);//make option text invisible

                } else if (b3.isChecked()) { // but when option state option can show option text (이거 선택되면 옵션 쓸 수 있음)
                    isOption = true;
                    option.setVisibility(View.VISIBLE);
                 }
            }
        });

        bt.setOnClickListener(new View.OnClickListener() { //when click pay button (버튼 누르면 이제 위에서 넣은 값에서 tip과 total을 찾아낸다.
            @Override
            public void onClick(View v) {
                boolean check = true; //check money is really money
                boolean isNumber = true; // check point number like 500.5

                string = editT.getText().toString(); // make money(string) from editT


                if (string.length() == 0) { //if you dont input number
                    Toast.makeText(getApplicationContext(), "Input Money. (Empty Value)", Toast.LENGTH_LONG).show();
                    check = false;
                } else if (string.charAt(0) == '-' || string.charAt(0) == '.') { //if you input minus number or you start '.'
                    Toast.makeText(getApplicationContext(), "Impossible. (Minus Value or No Number)", Toast.LENGTH_LONG).show();
                    check = false;
                }

                for (int i = 0; i < string.length(); i++) { // find this string is number
                    if (string.charAt(i) < '0' || string.charAt(i) > '9') {
                        if (string.charAt(i) == '.' && isNumber == true) { //when check 500.50
                            isNumber = false; //if it don not exist, than nonsense number like '500.50.2' is correct. wow it's terrible.
                            continue;
                        } else {
                            Toast.makeText(getApplicationContext(), "Nonsense. (This is Sentence)", Toast.LENGTH_LONG).show();
                            check = false;
                            break;
                        }
                    }
                }

                if (isOption == true && check == true) { // when you choose option radiobutton
                    Otip = option.getText().toString();

                    if (Otip.length() == 0 || Otip.length() > 2) { // when you input more than 99 or less than 1
                        Toast.makeText(getApplicationContext(), "Only Natural Number Between 1 ~ 99", Toast.LENGTH_LONG).show();
                        check = false;
                    }
                    for (int i = 0; i < string.length(); i++) { // find that number or not
                        if (string.charAt(i) < '0' || string.charAt(i) > '9') {
                            Toast.makeText(getApplicationContext(), "Tip is not Number", Toast.LENGTH_LONG).show();
                            check = false;
                        }
                    }

                    if (check == true) // final check the option value is number between 1~99 and natural number
                        tipP = Double.parseDouble(Otip) * 0.01;
                }

                if (check == true) { //there is no problem than do calculate.
                    cost = Double.parseDouble(string); // checking the money is number than input cost
                    tip = cost * tipP;
                    cost = cost + tip;
                    tipv.setText("TIP : " + tip); // show us all tip and total.
                    resultv.setText("TOTAL : " + cost);
                }
                else {
                    tipv.setText("");
                    resultv.setText("");
                }

            }
        });
    }

    // this section show all
    public void onStart() //just show start state
    {
        super.onStart();
        Toast.makeText(getApplicationContext(), "onStart", Toast.LENGTH_SHORT).show();

    }
    public void onRestart() //just show restart state
    {
        super.onRestart();
        Toast.makeText(getApplicationContext(), "onRestart", Toast.LENGTH_SHORT).show();
    }
    public void onResume() // show resume
    {
        super.onResume();
        Toast.makeText(getApplicationContext(), "onResume", Toast.LENGTH_SHORT).show();

    }
    public void onPause() // show pause
    {
        super.onPause();
        Toast.makeText(getApplicationContext(), "onPause", Toast.LENGTH_SHORT).show();

    }
    public void onStop() // show stop
    {
        super.onStop();
        Toast.makeText(getApplicationContext(), "onStop", Toast.LENGTH_SHORT).show();


    }
    public void onDestroy() // show destroy
    {
        super.onDestroy();
        Toast.makeText(getApplicationContext(), "onDestroy", Toast.LENGTH_SHORT).show();

    }
    //pause 상태에서 stop 상태로 가기전에 불러지는데 거기서 저장할 내용들을 저장하게 한다. onRestoreInstanceState은 oncreat에서 대신 하기 때문에 쓰지 않음.
    public void onSaveInstanceState( Bundle savedInstanceState ) { // when the step pause state the important value save. so we can reuse the value when restart.

        savedInstanceState.putString("Result", editT.getText().toString()); //
        savedInstanceState.putString("tip", tipv.getText().toString() ); //
        savedInstanceState.putString("total", resultv.getText().toString() ); //
        savedInstanceState.putString("option",option.getText().toString());
        savedInstanceState.putInt("radio", radioID);

        super.onSaveInstanceState(savedInstanceState);
        Toast.makeText(getApplicationContext(), "onSaveInstanceState", Toast.LENGTH_SHORT).show(); //show this state.
    }

}

